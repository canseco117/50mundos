#include <stdio.h>

int main() {
    printf("Hola Mundo\n");
    return 0;
}
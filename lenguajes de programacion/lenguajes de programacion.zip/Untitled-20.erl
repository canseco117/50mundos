-module(hola_mundo).
-export([hola_mundo/0]).

hola_mundo() ->
    io:fwrite("Hola Mundo\n").
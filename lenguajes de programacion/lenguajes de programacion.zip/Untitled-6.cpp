#include <iostream>

int main() {
    std::cout << "Hola Mundo" << std::endl;
    return 0;
}
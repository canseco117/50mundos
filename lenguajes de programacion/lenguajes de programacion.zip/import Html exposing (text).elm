import Html exposing (text)

main =
    text "Hola Mundo"